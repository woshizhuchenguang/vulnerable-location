extern int *glob;
void foo(void) {
        *glob = 2;
}
