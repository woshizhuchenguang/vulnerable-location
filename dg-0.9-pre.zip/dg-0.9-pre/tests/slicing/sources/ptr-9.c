extern int *glob;

int *ptr() {
        // return what is in glob
        return glob;
}
