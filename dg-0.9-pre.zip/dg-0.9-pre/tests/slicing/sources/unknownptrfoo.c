int *foo(int *a)
{
	*a = 8;
	return a;
}
