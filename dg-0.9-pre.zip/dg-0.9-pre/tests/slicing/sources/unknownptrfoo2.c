extern int a;

int *foo() {
	return &a;
}
