struct m;
struct m *get_ptr(struct m *m)
{
	return m;
}
