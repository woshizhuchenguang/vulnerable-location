int *a_ptr(int **b) {
        return *b;
}
