#include "dg/BBlockBase.h"

namespace dg {

unsigned BBlockId::idcnt = 0;

}
