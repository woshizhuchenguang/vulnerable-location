#ifdef DEBUG_ENABLED
namespace dg {
namespace debug {

unsigned _debug_lvl = 0;
unsigned _ind = 0;

} // namespace debug
} // namespace dg

#endif
