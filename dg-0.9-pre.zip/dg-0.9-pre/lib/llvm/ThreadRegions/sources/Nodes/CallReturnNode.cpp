#include "CallReturnNode.h"

CallReturnNode::CallReturnNode():Node(NodeType::CALL_RETURN)
{}
