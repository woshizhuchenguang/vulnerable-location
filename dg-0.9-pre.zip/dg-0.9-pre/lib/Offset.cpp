#include "dg/Offset.h"

namespace dg {
// set the value of UNKNOWN offset
const Offset::type Offset::UNKNOWN = ~(static_cast<Offset::type>(0));
}

