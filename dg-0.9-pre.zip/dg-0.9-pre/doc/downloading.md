# Getting pre-compiled DG

You can obtain pre-compiled DG project in several forms.

## Docker image

You can download the image from [Docker Hub](https://hub.docker.com/r/mchalupa/dg). The image
contains, apart from DG, also vim and emacs editors and clang, so you can try dg out!

## Archlinux AUR package

There is also the [dg-git](https://aur.archlinux.org/packages/dg-git/) AUR package for Archlinux users.
